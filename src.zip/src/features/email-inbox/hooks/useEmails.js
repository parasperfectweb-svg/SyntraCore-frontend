// features/email-inbox/hooks/useEmails.js
// Owns the Email Inbox page's data + selection state: fetching the list,
// which email is selected, read/unread status, and the All/Unread filter.
import { useState, useEffect, useMemo, useCallback } from 'react';
import { fetchEmails, markEmailRead } from '../api/emailApi';

export function useEmails() {
  const [emails, setEmails] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedId, setSelectedId] = useState(null);
  const [filter, setFilter] = useState('all'); // 'all' | 'unread'

  useEffect(() => {
    let cancelled = false;

    setLoading(true);
    setError(null);

    fetchEmails()
      .then((data) => {
        if (cancelled) return;
        setEmails(data);
        setSelectedId(data[0]?.id ?? null);
      })
      .catch((err) => {
        if (cancelled) return;
        // Previously swallowed silently — a failed request left the
        // inbox stuck on its empty initial state with no indication
        // anything had gone wrong. Surface it instead.
        console.error('fetchEmails failed:', err);
        setError(err.message || 'Failed to load emails');
      })
      .finally(() => {
        if (cancelled) return;
        setLoading(false);
      });

    return () => { cancelled = true; };
  }, []);

  const selectEmail = useCallback((id) => {
    setSelectedId(id);
    setEmails((prev) => prev.map((e) => (e.id === id ? { ...e, unread: false } : e)));
    markEmailRead(id);
  }, []);

  const visibleEmails = useMemo(
    () => (filter === 'unread' ? emails.filter((e) => e.unread) : emails),
    [emails, filter]
  );

  const selectedEmail = useMemo(
    () => emails.find((e) => e.id === selectedId) ?? null,
    [emails, selectedId]
  );

  const unreadCount = useMemo(() => emails.filter((e) => e.unread).length, [emails]);

  return {
    emails: visibleEmails,
    loading,
    error,
    selectedEmail,
    selectedId,
    selectEmail,
    filter,
    setFilter,
    unreadCount,
  };
}
