// features/email-inbox/EmailInboxPage.jsx
import { useState } from 'react';
import './EmailInbox.css';
import FavoritesPanel from './components/FavoritesPanel';
import EmailList from './components/EmailList';
import EmailDetail from './components/EmailDetail';
import CopilotPanel from './components/CopilotPanel';
import { useEmails } from './hooks/useEmails';
import { useLogisticsForEmail } from './hooks/useLogisticsForEmail';

export default function EmailInboxPage() {
  const {
    emails, selectedEmail, selectedId, selectEmail, filter, setFilter, loading, error,
  } = useEmails();
  const [copilotOpen, setCopilotOpen] = useState(false);
  // Fetches GET /emails/logistics/{emailId} for whichever email is
  // currently selected, instead of pulling all 100 logistics records
  // up front and matching client-side (see the old useLogistics.js).
  const { logistics, loading: logisticsLoading } = useLogisticsForEmail(selectedEmail?.id);
  // Mobile only: which pane is showing — the inbox list or the open
  // email. Desktop always renders both side by side (see EmailInbox.css,
  // `.sc-app[data-screen=...]` rules only apply below 639px).
  const [screen, setScreen] = useState('list');
  const [replyValue, setReplyValue] = useState('');

  const handleSelectEmail = (id) => {
    selectEmail(id);
    setScreen('detail');
  };

  const handleBackToList = () => setScreen('list');

  const handleSendReply = () => {
    if (!replyValue.trim()) return;
    // No send API yet — clear the draft so the box resets like a sent
    // reply would. Wire this to a real send endpoint later.
    setReplyValue('');
  };

  // Copilot's "Use in Reply" button hands its draft text here so the
  // person can review/edit it in the real reply box before sending.
  const handleUseDraft = (text) => {
    setReplyValue(text);
    setCopilotOpen(false);
  };

  return (
    <div className="sc-email-inbox sc-app sc-main-row flex-grow-1 d-flex overflow-hidden h-100" data-screen={screen}>
      <FavoritesPanel />
      <EmailList
        emails={emails}
        selectedId={selectedId}
        onSelect={handleSelectEmail}
        filter={filter}
        onFilterChange={setFilter}
        loading={loading}
        error={error}
      />
      <EmailDetail
        email={selectedEmail}
        onBack={handleBackToList}
        replyValue={replyValue}
        onReplyChange={setReplyValue}
        onSend={handleSendReply}
        onOpenCopilot={() => setCopilotOpen(true)}
      />
      <CopilotPanel
        open={copilotOpen}
        onClose={() => setCopilotOpen(false)}
        onUseDraft={handleUseDraft}
        logistics={logistics}
        logisticsLoading={logisticsLoading}
      />

      <button
        type="button"
        aria-label="Open Copilot AI Assistant"
        data-tooltip="Reply with Copilot"
        className="sc-ai-fab d-none rounded-circle border align-items-center justify-content-center"
        onClick={() => setCopilotOpen(true)}
      >
        <svg width="20" height="20" viewBox="0 0 16 16" fill="none">
          <path d="M8 1.17l1.05 4.1c.1.36.29.68.56.95.27.27.6.46.95.56l4.1 1.05-4.1 1.05c-.36.1-.68.29-.95.56-.27.27-.46.6-.56.95L8 14.83l-1.05-4.1a2 2 0 00-.56-.95 2 2 0 00-.95-.56L1.34 8.17l4.1-1.05c.36-.1.68-.29.95-.56.27-.27.46-.6.56-.95L8 1.17z"
          stroke="#7c3aed" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33" />
        </svg>
      </button>
    </div>
  );
}